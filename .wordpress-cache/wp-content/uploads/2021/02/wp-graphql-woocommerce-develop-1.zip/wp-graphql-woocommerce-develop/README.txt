=== WP GraphQL WooCommerce ===
Contributors: kidunot89, ranaaterning, jasonbahl, saleebm
Tags: GraphQL, WooCommerce, WPGraphQL
Requires at least: 4.9
Tested up to: 5.2
Requires PHP: 7.1
Requires WooCommerce: 4.8.0
Requires WPGraphQL: 1.0.0+
Works with WPGraphQL-JWT-Authentication: 0.4.0+
Stable tag: 0.7.0
License: GPL-3
License URI: https://www.gnu.org/licenses/gpl-3.0.html
Maintained at: https://github.com/wp-graphql/wp-graphql-woocommerce

== Description ==
Adds WooCommerce functionality to the WPGraphQL schema.
